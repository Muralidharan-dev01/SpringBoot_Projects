package com.bank.app;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

}
