package com.ecommerce.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmEcomApplicationTests {

	@Test
	void contextLoads() {
	}

}
